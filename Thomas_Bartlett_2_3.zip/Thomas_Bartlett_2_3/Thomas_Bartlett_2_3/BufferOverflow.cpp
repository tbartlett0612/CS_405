// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Thomas Bartlett
// September 8, 2023
// Module 2-3 activity
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_order
  //  varaible, and its position in the declaration. It must always be directly before the variable used for input.

  const std::string account_number = "CharlieBrown42";
  char user_input[21];//changed to 21 to allow 20 characters of the input to show.
  std::cout << "Enter a value: ";
  //std::cin >> user_input; --> This line was changed to the code below.
  std::cin.getline(user_input, 21);//used getline to be able to take in the input and then just use the first 20 characters.

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
